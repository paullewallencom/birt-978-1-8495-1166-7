1667: BIRT 2.6 Data Analysis and Reporting

Chapter 1: No code
Chapter 2: No code
Chapter 3: No code
Chapter 4: Code present
Chapter 5: Code present
Chapter 6: Code present
Chapter 7: No code
Chapter 8: Code present
Chapter 9: Code present
Chapter 10: Code present
Chapter 11: No code
Chapter 12: Code present